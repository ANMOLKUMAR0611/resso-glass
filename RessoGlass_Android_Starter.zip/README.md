# Resso Glass — Android starter

A private, Resso-inspired Android music-player UI starter with a dark premium glass visual system.

## Open
1. Extract the ZIP.
2. Open the `RessoGlass` folder in Android Studio.
3. Let Gradle sync.
4. Run on an Android phone or tablet (API 26+).

## Current starter scope
- Responsive phone bottom navigation and tablet side navigation.
- Dark black / purple / violet visual direction.
- Home, Search, and Library starter screens.
- Demo track rows and a visual mini-player shell.

## Important next implementation steps
This is the UI foundation, not a finished streaming service. The demo tracks are placeholders and do not play audio yet.
1. Add a system audio picker and wire local audio files to Media3 ExoPlayer.
2. Add a MediaSessionService for background playback, notification and lock-screen controls.
3. Add licensed streaming catalogue/API access if online music is required.
4. Add persistent playlists, favourites, search indexing and synced lyrics from permitted providers.

Use music files and artwork you own or are licensed to use. No ads or ad SDKs are included.
