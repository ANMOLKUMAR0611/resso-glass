package com.example.ressoglass

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalConfiguration

private val Ink = Color(0xFF09070F)
private val Panel = Color(0xFF171222)
private val Purple = Color(0xFF9B5CFF)
private val Violet = Color(0xFF5B35B8)
private val Muted = Color(0xFFB8AEC9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RessoGlassApp() }
    }
}

private data class Track(val title: String, val artist: String, val tint: Color)

private val demoTracks = listOf(
    Track("Midnight City", "M83 • Sample track", Color(0xFF6C3CCB)),
    Track("Afterglow", "Electronic • Sample track", Color(0xFF9B4D91)),
    Track("Velvet Sky", "Indie • Sample track", Color(0xFF3C6A9B)),
    Track("Neon Hearts", "Pop • Sample track", Color(0xFF9B5C55))
)

@Composable
fun RessoGlassApp() {
    var selectedTab by remember { mutableStateOf("Home") }
    var currentTrack by remember { mutableStateOf(demoTracks.first()) }
    var playing by remember { mutableStateOf(false) }
    val width = LocalConfiguration.current.screenWidthDp
    val tablet = width >= 600

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Purple,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF211333), Ink, Color(0xFF08070C)))
        )) {
            Row(Modifier.fillMaxSize()) {
                if (tablet) {
                    GlassNavigation(selectedTab, true) { selectedTab = it }
                }
                Column(Modifier.weight(1f).fillMaxHeight()) {
                    TopBar()
                    when (selectedTab) {
                        "Search" -> SearchScreen()
                        "Library" -> LibraryScreen()
                        else -> HomeScreen(
                            onTrack = { currentTrack = it; playing = true },
                            currentTrack = currentTrack
                        )
                    }
                    MiniPlayer(currentTrack, playing, onPlay = { playing = !playing })
                    if (!tablet) GlassNavigation(selectedTab, false) { selectedTab = it }
                }
            }
        }
    }
}

@Composable
private fun TopBar() {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("RESSO", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("FEEL EVERY BEAT", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
        }
        Box(
            Modifier.size(42.dp).clip(CircleShape)
                .background(Color.White.copy(alpha = .08f))
                .border(1.dp, Color.White.copy(alpha = .14f), CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Person, null, tint = Color.White) }
    }
}

@Composable
private fun HomeScreen(onTrack: (Track) -> Unit, currentTrack: Track) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 14.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            Text("Good evening", color = Muted, fontSize = 14.sp)
            Text("Find your rhythm.", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        }
        item {
            GlassPanel(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("YOUR SOUND, YOUR SPACE", color = Purple, fontSize = 10.sp, letterSpacing = 1.5.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Music without
interruptions.", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Text("Ad-free listening • Personal library", color = Muted, fontSize = 11.sp)
                    }
                    AlbumArt("✦", Modifier.size(104.dp), Color(0xFF4B267B))
                }
            }
        }
        item { SectionHeading("Made for your mood", "See all") }
        items(demoTracks) { track ->
            TrackRow(track, selected = track == currentTrack) { onTrack(track) }
        }
        item {
            SectionHeading("Recently played", "History")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AlbumArt("♫", Modifier.weight(1f).height(112.dp), Color(0xFF5D347E))
                AlbumArt("◈", Modifier.weight(1f).height(112.dp), Color(0xFF354C83))
                AlbumArt("✧", Modifier.weight(1f).height(112.dp), Color(0xFF813E70))
            }
        }
    }
}

@Composable
private fun SearchScreen() {
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Search", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        GlassPanel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, null, tint = Muted)
                Spacer(Modifier.width(10.dp))
                TextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("Songs, artists, albums", color = Muted) },
                    modifier = Modifier.weight(1f),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = Purple,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    singleLine = true
                )
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("Explore genres", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        listOf("Chill", "Pop", "Electronic", "Indie", "Focus", "Workout").chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEachIndexed { index, genre ->
                    GlassPanel(Modifier.weight(1f).padding(bottom = 10.dp)) {
                        Text(genre, color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun LibraryScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Your library", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        listOf("Liked songs", "Playlists", "Albums", "Artists", "Downloaded music").forEach {
            GlassPanel(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LibraryMusic, null, tint = Purple)
                    Spacer(Modifier.width(14.dp))
                    Text(it, color = Color.White, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                }
            }
        }
    }
}

@Composable
private fun GlassNavigation(selected: String, vertical: Boolean, onSelect: (String) -> Unit) {
    val tabs = listOf("Home", "Search", "Library")
    if (vertical) {
        Column(
            Modifier.width(92.dp).fillMaxHeight().padding(12.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Color.White.copy(alpha = .055f))
                .border(1.dp, Color.White.copy(alpha = .12f), RoundedCornerShape(28.dp))
                .padding(vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            tabs.forEach { tab ->
                NavigationItem(tab, selected == tab, true) { onSelect(tab) }
            }
        }
    } else {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xDD1B1428))
                .border(1.dp, Color.White.copy(alpha = .14f), RoundedCornerShape(24.dp))
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            tabs.forEach { tab -> NavigationItem(tab, selected == tab, false) { onSelect(tab) } }
        }
    }
}

@Composable
private fun NavigationItem(tab: String, selected: Boolean, vertical: Boolean, onClick: () -> Unit) {
    val icon = when (tab) {
        "Home" -> Icons.Default.Home
        "Search" -> Icons.Default.Search
        else -> Icons.Default.LibraryMusic
    }
    Column(
        Modifier.padding(horizontal = 12.dp, vertical = 8.dp).clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).background(if (selected) Purple.copy(alpha = .22f) else Color.Transparent)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = if (selected) Color.White else Muted)
        if (!vertical) {
            Spacer(Modifier.height(3.dp))
            Text(tab, color = if (selected) Color.White else Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun MiniPlayer(track: Track, playing: Boolean, onPlay: () -> Unit) {
    GlassPanel(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AlbumArt("♫", Modifier.size(44.dp), track.tint)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(track.artist, color = Muted, fontSize = 10.sp)
            }
            IconButton(onClick = onPlay) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White)
            }
            Icon(Icons.Default.SkipNext, null, tint = Color.White)
        }
    }
}

@Composable
private fun TrackRow(track: Track, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick)
            .background(if (selected) Purple.copy(alpha = .14f) else Color.Transparent)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AlbumArt("♫", Modifier.size(54.dp), track.tint)
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(track.artist, color = Muted, fontSize = 11.sp)
        }
        Icon(Icons.Default.MoreHoriz, null, tint = Muted)
    }
}

@Composable
private fun AlbumArt(symbol: String, modifier: Modifier, tint: Color) {
    Box(
        modifier.clip(RoundedCornerShape(18.dp))
            .background(Brush.linearGradient(listOf(tint, Color(0xFF171020), Purple.copy(alpha = .6f)))),
        contentAlignment = Alignment.Center
    ) {
        Text(symbol, color = Color.White.copy(alpha = .9f), fontSize = 34.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
private fun SectionHeading(title: String, action: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text(action, color = Purple, fontSize = 12.sp)
    }
}

@Composable
private fun GlassPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(24.dp))
            .background(Color.White.copy(alpha = .075f))
            .border(1.dp, Color.White.copy(alpha = .13f), RoundedCornerShape(24.dp))
            .padding(16.dp),
        content = content
    )
}
